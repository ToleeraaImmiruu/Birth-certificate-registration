<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Birth Certificate Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 600px;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="card shadow p-4">
            <h4 class="text-center text-primary">Birth Certificate Application</h4>
            <form id="applicationForm">
                <h5 class="text-primary">Personal Information</h5>
                <div class="mb-3">
                    <label for="first_name" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                </div>
                <div class="mb-3">
                    <label for="middle_name" class="form-label">Middle Name</label>
                    <input type="text" class="form-control" id="middle_name" name="middle_name">
                </div>
                <div class="mb-3">
                    <label for="last_name" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="dob" class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" id="dob" name="dob" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="gender" class="form-label">Gender</label>
                    <select class="form-select" id="gender" name="gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="birth_place" class="form-label">Place of Birth</label>
                    <input type="text" class="form-control" id="birth_place" name="birth_place" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>

                <h5 class="text-primary">Contact Details</h5>
                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" class="form-control" id="address" name="address" required>
                </div>
                <div class="mb-3">
                    <label for="father_name" class="form-label">Father’s Full Name</label>
                    <input type="text" class="form-control" id="father_name" name="father_name" required>
                </div>
                <div class="mb-3">
                    <label for="mother_name" class="form-label">Mother’s Full Name</label>
                    <input type="text" class="form-control" id="mother_name" name="mother_name" required>
                </div>


                <h5 class="text-primary">Supporting Documents</h5>
                <div class="mb-3">
                    <label for="parent_id_proof" class="form-label">Father's ID (JPG, PNG)</label>
                    <input type="file" class="form-control" id="father_id_proof" name="father_id_proof" accept=".jpg,.png" required>
                </div>
                <div class="mb-3">
                    <label for="parent_id_proof" class="form-label">Mother’s ID (JPG, PNG)</label>
                    <input type="file" class="form-control" id="mother_id_proof" name="mother_id_proof" accept=".jpg,.png" required>
                </div>
                <div class="mb-3">
                    <label for="applicant_id_proof" class="form-label">Applicant ID (JPG, PNG) if applicant is > 18 years old</label>
                    <input type="file" class="form-control" id="applicant_id_proof" name="applicant_id_proof" accept=".jpg,.png">
                </div>
                <div class="mb-3">
                    <label for="birth_record" class="form-label">Hospital Birth Record</label>
                    <input type="file" class="form-control" id="birth_record" name="birth_record" accept=".pdf,.jpg,.png">
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="agree" required>
                    <label class="form-check-label" for="agree">I confirm that all information provided is true and correct.</label>
                </div>

                <button type="submit" class="btn btn-primary w-100">Submit Application</button>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('applicationForm').addEventListener('submit', function(event) {
            let valid = true;
            let firstName = document.getElementById('first_name').value.trim();
            let lastName = document.getElementById('last_name').value.trim();
            let email = document.getElementById('email').value.trim();
            let address = document.getElementById('address').value.trim();
            let parentID = document.getElementById('parent_id_proof').value;

            if (!firstName || !lastName || !email || !address || !parentID) {
                valid = false;
            }

            if (!valid) {
                alert('Please fill in all required fields.');
                event.preventDefault();
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>